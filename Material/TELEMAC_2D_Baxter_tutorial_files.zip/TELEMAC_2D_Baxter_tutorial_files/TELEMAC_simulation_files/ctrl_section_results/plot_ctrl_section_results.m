%Purpose: the purpose of this file is to read and plot the inflow and 
%         outflow hydrographs from the TELEMAC-2D Baxter tutorial.

%Note: you will have to change the ctrl_section name to the corresponding 
%      control section results file of interest.

%Cheers, 
%CGM
%==========================================================================
clear all
close all
%==========================================================================
%% load data
ctrl_section_results = importdata('unsteady_ctrl_section_results.txt');

hydrograph = importdata('..\inflow_hydrograph\hydrographs_baxter.liq');
%% plot figure
figure()
plot(ctrl_section_results.data(:,1),ctrl_section_results.data(:,2:4),'linewidth',2);
hold on;
plot(hydrograph.data(:,1),hydrograph.data(:,2:end),'k--','linewidth',2);
xlabel('Time, seconds')
ylabel('Discharge, m^3/s')
legend('Tule Creek','Baxter Upstream','Baxter Downstream','Baxter Inflow','Tule Inflow')
title('Outflow Hydrograph - Baxter River and Tule Creek')
set(gca,'fontsize',12)